﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MembreSTE
{
    public class GestionnaireSTE
    {
        List<Donnateur> donnateurs;
        List<Commandiatire> commanditaires;
        List<Don> dons;
        List<Prix> prix;

        public List<Donnateur> Donnateurs
        {
            get
            {
                return donnateurs;
            }

            set
            {
                donnateurs = value;
            }
        }

        public List<Commandiatire> Commanditaires
        {
            get
            {
                return commanditaires;
            }

            set
            {
                commanditaires = value;
            }
        }

        public List<Don> Dons
        {
            get
            {
                return dons;
            }

            set
            {
                dons = value;
            }
        }

        public List<Prix> Prix
        {
            get
            {
                return prix;
            }

            set
            {
                prix = value;
            }
        }

        public GestionnaireSTE()
        {
            donnateurs = new List<Donnateur>();
            commanditaires = new List<Commandiatire>();
            dons = new List<Don>();
            prix = new List<Prix>();

            string ligne;
            string[] donne;
            string nomFichier = "commanditaires.txt";
            if (File.Exists(nomFichier))
            {
                StreamReader lecteur = new StreamReader(nomFichier);
                while ((ligne = lecteur.ReadLine()) != null)
                {
                    donne = ligne.Split(',');
                    commanditaires.Add(new Commandiatire(donne[0], donne[1], donne[2]));
                }
                lecteur.Close();
            }
            else
            {
                throw new Exception($" Le fichier { nomFichier} n’existe pas dans mon répertoire.");
                
            }

            donne = null;

            nomFichier = "prix.txt";
            if (File.Exists(nomFichier))
            {
                StreamReader lecteur = new StreamReader(nomFichier);
                while ((ligne = lecteur.ReadLine()) != null)
                {
                    donne = ligne.Split(',');
                    prix.Add(new Prix(donne[0], donne[1], Double.Parse(donne[2]), Double.Parse(donne[3]), Int32.Parse(donne[4]), donne[5]));
                }
                lecteur.Close();
                
            }
            else
            {
                throw new Exception($" Le fichier { nomFichier} n’existe pas dans mon répertoire.");
            }

            donne = null;

            nomFichier = "donnateurs.txt";
            if (File.Exists(nomFichier))
            {
                StreamReader lecteur = new StreamReader(nomFichier);
                while ((ligne = lecteur.ReadLine()) != null)
                {
                    donne = ligne.Split(',');
                    donnateurs.Add(new Donnateur(donne[0], donne[1], donne[2], donne[3], donne[4], (donne[5])[0], donne[6], donne[7]));
                }
                lecteur.Close();
            }
            else
            {
                throw new Exception($" Le fichier { nomFichier} n’existe pas dans mon répertoire.");
                
            }

            donne = null;

            nomFichier = "donns.txt";
            if (File.Exists(nomFichier))
            {
                StreamReader lecteur = new StreamReader(nomFichier);
                while ((ligne = lecteur.ReadLine()) != null)
                {
                    donne = ligne.Split(',');
                    dons.Add(new Don(donne[0], donne[1], donne[2], Double.Parse(donne[3]), donne[4]));
                }
                lecteur.Close();
            }
            else
            {

                throw new Exception($" Le fichier { nomFichier} n’existe pas dans mon répertoire.");
                
            }

        }

        public void AjouterDonnateur(string iDDonateur, string prenom, string surnom, string adresse, string telephone, char typeDeCarte, string numeroDeCarte, string dateExpiration)
        {
            donnateurs.Add(new Donnateur(iDDonateur, prenom, surnom, adresse, telephone, typeDeCarte, numeroDeCarte, dateExpiration));
        }

        public void AjouterCommanditaire(string iDCommanditaire, string prenom, string surnom)
        {
            commanditaires.Add(new Commandiatire(iDCommanditaire, prenom, surnom));
        }

        public void AjouterPrix(string iDPrix, string description, double valeur, double donMinimum, int qnte_Originale, string iDCommanditaire)
        {
            prix.Add(new Prix(iDPrix, description, valeur, donMinimum, qnte_Originale, iDCommanditaire));
        }

        public void AjouterDon(string iDDon, string dateDuDon, string iDDonateur, double montantDuDon, string iDPrix)
        {
            dons.Add(new Don(iDDon, dateDuDon, iDDonateur, montantDuDon, iDPrix));
        }

        public string AfficherDonnateur()
        {
            string ds = "";
            foreach (Donnateur d in Donnateurs)
            {
                ds += d.ToString() + "\n";
            }
            return ds;
        }

        public string AfficherCommanditaires()
        {
            string cs = "";
            foreach (Commandiatire c in Commanditaires)
            {
                cs += c.ToString() + "\n";
            }
            return cs;
        }

        public string AfficherPrix()
        {
            string ps = "";
            foreach (Prix p in Prix)
            {
                ps += p.ToString() + "\n";
            }
            return ps;
        }

        public string AfficherDons()
        {
            string ds = "";
            foreach (Don d in Dons)
            {
                ds += d.ToString() + "\n";
            }
            return ds;
        }

        public bool AttribuerPrix(double a)
        {
            if (a > 50 && a <= 199)
            {
                //dons// idprix
            }
            else if (a <= 349)
            {

            }
            else if (a <= 500)
            {

            }
            else
            {

            }
            return false;
        }

        /*public void Importer(string nomFichier)
        {
            string ligne;
            string[] donnats;
            if (!File.Exists(nomFichier))
            {
                throw new Exception($" Le fichier { nomFichier} n’existe pas dans mon répertoire.");
            }
            else
            {
                StreamReader lecteur = new StreamReader(nomFichier);
                while ((ligne = lecteur.ReadLine()) != null)
                {
                    donnats = ligne.Split(',');
                    donnateurs.Add(new Donnateur(donnats[0], donnats[1], donnats[2], donnats[3], donnats[4], (donnats[5])[0], donnats[6], donnats[7]));
                }
                lecteur.Close();
            }

        }*/

        public void Exporter(string nomFichier)
        {
           StreamWriter ecrivans = new StreamWriter(nomFichier);
             foreach (Donnateur d in donnateurs)
             {
                 ecrivans.WriteLine(d.ToString() + "\n");
             }
            ecrivans.Close();
          
        }

    }
}
