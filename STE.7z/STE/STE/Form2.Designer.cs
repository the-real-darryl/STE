﻿namespace STE
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnAfficherDonneur = new System.Windows.Forms.Button();
            this.btnAjouterDonneur = new System.Windows.Forms.Button();
            this.btnAfficherDon = new System.Windows.Forms.Button();
            this.btnAjouterDon = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtNombreDePrix = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtIDPrixDonneurs = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtDateExpirationCarte = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtNumeroCarte = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.grBoxTypeCarte = new System.Windows.Forms.GroupBox();
            this.rbAmex = new System.Windows.Forms.RadioButton();
            this.rbMasterCard = new System.Windows.Forms.RadioButton();
            this.rbVisa = new System.Windows.Forms.RadioButton();
            this.txtMontantDon = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtIDDon = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txtTelDonneur = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtAdresseDonneur = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtNomDonneur = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtPrenomDonneur = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtIDDonneur = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btnAfficherPrix = new System.Windows.Forms.Button();
            this.btnAjouterPrix = new System.Windows.Forms.Button();
            this.btnAfficherCommanditaire = new System.Windows.Forms.Button();
            this.btnAjouterCommanditaire = new System.Windows.Forms.Button();
            this.txtDonMinimumPrix = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtQuantitePrix = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtValeurPrix = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtDescriptionPrix = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtIDPrixCommanditaire = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtIDCommanditaire = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNomCommanditaire = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtPrenomCommanditaire = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnFermer = new System.Windows.Forms.Button();
            this.rtbArea = new System.Windows.Forms.RichTextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fichierToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exporterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.grBoxTypeCarte.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 40);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(500, 363);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnAfficherDonneur);
            this.tabPage1.Controls.Add(this.btnAjouterDonneur);
            this.tabPage1.Controls.Add(this.btnAfficherDon);
            this.tabPage1.Controls.Add(this.btnAjouterDon);
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.txtMontantDon);
            this.tabPage1.Controls.Add(this.label18);
            this.tabPage1.Controls.Add(this.txtIDDon);
            this.tabPage1.Controls.Add(this.label19);
            this.tabPage1.Controls.Add(this.label17);
            this.tabPage1.Controls.Add(this.txtTelDonneur);
            this.tabPage1.Controls.Add(this.label16);
            this.tabPage1.Controls.Add(this.txtAdresseDonneur);
            this.tabPage1.Controls.Add(this.label15);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.txtNomDonneur);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.txtPrenomDonneur);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Controls.Add(this.txtIDDonneur);
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(492, 337);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Donneurs";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnAfficherDonneur
            // 
            this.btnAfficherDonneur.Location = new System.Drawing.Point(380, 305);
            this.btnAfficherDonneur.Name = "btnAfficherDonneur";
            this.btnAfficherDonneur.Size = new System.Drawing.Size(102, 23);
            this.btnAfficherDonneur.TabIndex = 42;
            this.btnAfficherDonneur.Text = "Afficher Donneur";
            this.btnAfficherDonneur.UseVisualStyleBackColor = true;
            this.btnAfficherDonneur.Click += new System.EventHandler(this.btnAfficherDonneur_Click);
            // 
            // btnAjouterDonneur
            // 
            this.btnAjouterDonneur.Location = new System.Drawing.Point(380, 276);
            this.btnAjouterDonneur.Name = "btnAjouterDonneur";
            this.btnAjouterDonneur.Size = new System.Drawing.Size(102, 23);
            this.btnAjouterDonneur.TabIndex = 41;
            this.btnAjouterDonneur.Text = "Ajouter Donneur";
            this.btnAjouterDonneur.UseVisualStyleBackColor = true;
            this.btnAjouterDonneur.Click += new System.EventHandler(this.btnAjouterDonneur_Click);
            // 
            // btnAfficherDon
            // 
            this.btnAfficherDon.Location = new System.Drawing.Point(380, 248);
            this.btnAfficherDon.Name = "btnAfficherDon";
            this.btnAfficherDon.Size = new System.Drawing.Size(102, 23);
            this.btnAfficherDon.TabIndex = 40;
            this.btnAfficherDon.Text = "Afficher Don";
            this.btnAfficherDon.UseVisualStyleBackColor = true;
            this.btnAfficherDon.Click += new System.EventHandler(this.btnAfficherDon_Click);
            // 
            // btnAjouterDon
            // 
            this.btnAjouterDon.Location = new System.Drawing.Point(380, 219);
            this.btnAjouterDon.Name = "btnAjouterDon";
            this.btnAjouterDon.Size = new System.Drawing.Size(102, 23);
            this.btnAjouterDon.TabIndex = 39;
            this.btnAjouterDon.Text = "Ajouter Don";
            this.btnAjouterDon.UseVisualStyleBackColor = true;
            this.btnAjouterDon.Click += new System.EventHandler(this.btnAjouterDon_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtNombreDePrix);
            this.groupBox3.Controls.Add(this.label22);
            this.groupBox3.Controls.Add(this.txtIDPrixDonneurs);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.button6);
            this.groupBox3.Location = new System.Drawing.Point(236, 200);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(126, 129);
            this.groupBox3.TabIndex = 38;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Attribuer Prix";
            // 
            // txtNombreDePrix
            // 
            this.txtNombreDePrix.Location = new System.Drawing.Point(56, 79);
            this.txtNombreDePrix.Name = "txtNombreDePrix";
            this.txtNombreDePrix.Size = new System.Drawing.Size(60, 20);
            this.txtNombreDePrix.TabIndex = 35;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(6, 82);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(44, 13);
            this.label22.TabIndex = 34;
            this.label22.Text = "Nombre";
            // 
            // txtIDPrixDonneurs
            // 
            this.txtIDPrixDonneurs.Location = new System.Drawing.Point(56, 53);
            this.txtIDPrixDonneurs.Name = "txtIDPrixDonneurs";
            this.txtIDPrixDonneurs.Size = new System.Drawing.Size(60, 20);
            this.txtIDPrixDonneurs.TabIndex = 33;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(6, 56);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(38, 13);
            this.label23.TabIndex = 32;
            this.label23.Text = "ID Prix";
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(23, 19);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 0;
            this.button6.Text = "Attribuer Prix";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtDateExpirationCarte);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.txtNumeroCarte);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.grBoxTypeCarte);
            this.groupBox1.Location = new System.Drawing.Point(236, 16);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(246, 150);
            this.groupBox1.TabIndex = 37;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Carte de crédit";
            // 
            // txtDateExpirationCarte
            // 
            this.txtDateExpirationCarte.Location = new System.Drawing.Point(104, 119);
            this.txtDateExpirationCarte.Name = "txtDateExpirationCarte";
            this.txtDateExpirationCarte.Size = new System.Drawing.Size(134, 20);
            this.txtDateExpirationCarte.TabIndex = 35;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(12, 122);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(86, 13);
            this.label20.TabIndex = 34;
            this.label20.Text = "Date d\'expiration";
            // 
            // txtNumeroCarte
            // 
            this.txtNumeroCarte.Location = new System.Drawing.Point(104, 93);
            this.txtNumeroCarte.Name = "txtNumeroCarte";
            this.txtNumeroCarte.Size = new System.Drawing.Size(134, 20);
            this.txtNumeroCarte.TabIndex = 33;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(12, 96);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(44, 13);
            this.label21.TabIndex = 32;
            this.label21.Text = "Numéro";
            // 
            // grBoxTypeCarte
            // 
            this.grBoxTypeCarte.Controls.Add(this.rbAmex);
            this.grBoxTypeCarte.Controls.Add(this.rbMasterCard);
            this.grBoxTypeCarte.Controls.Add(this.rbVisa);
            this.grBoxTypeCarte.Location = new System.Drawing.Point(6, 19);
            this.grBoxTypeCarte.Name = "grBoxTypeCarte";
            this.grBoxTypeCarte.Size = new System.Drawing.Size(178, 62);
            this.grBoxTypeCarte.TabIndex = 0;
            this.grBoxTypeCarte.TabStop = false;
            this.grBoxTypeCarte.Text = "Type de carte";
            // 
            // rbAmex
            // 
            this.rbAmex.AutoSize = true;
            this.rbAmex.Location = new System.Drawing.Point(116, 25);
            this.rbAmex.Name = "rbAmex";
            this.rbAmex.Size = new System.Drawing.Size(55, 17);
            this.rbAmex.TabIndex = 2;
            this.rbAmex.TabStop = true;
            this.rbAmex.Text = "AMEX";
            this.rbAmex.UseVisualStyleBackColor = true;
            // 
            // rbMasterCard
            // 
            this.rbMasterCard.AutoSize = true;
            this.rbMasterCard.Location = new System.Drawing.Point(69, 25);
            this.rbMasterCard.Name = "rbMasterCard";
            this.rbMasterCard.Size = new System.Drawing.Size(41, 17);
            this.rbMasterCard.TabIndex = 1;
            this.rbMasterCard.TabStop = true;
            this.rbMasterCard.Text = "MC";
            this.rbMasterCard.UseVisualStyleBackColor = true;
            // 
            // rbVisa
            // 
            this.rbVisa.AutoSize = true;
            this.rbVisa.Location = new System.Drawing.Point(6, 25);
            this.rbVisa.Name = "rbVisa";
            this.rbVisa.Size = new System.Drawing.Size(45, 17);
            this.rbVisa.TabIndex = 0;
            this.rbVisa.TabStop = true;
            this.rbVisa.Text = "Visa";
            this.rbVisa.UseVisualStyleBackColor = true;
            // 
            // txtMontantDon
            // 
            this.txtMontantDon.Location = new System.Drawing.Point(86, 254);
            this.txtMontantDon.Name = "txtMontantDon";
            this.txtMontantDon.Size = new System.Drawing.Size(134, 20);
            this.txtMontantDon.TabIndex = 36;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(22, 257);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(46, 13);
            this.label18.TabIndex = 35;
            this.label18.Text = "Montant";
            // 
            // txtIDDon
            // 
            this.txtIDDon.Location = new System.Drawing.Point(86, 228);
            this.txtIDDon.Name = "txtIDDon";
            this.txtIDDon.Size = new System.Drawing.Size(134, 20);
            this.txtIDDon.TabIndex = 34;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(22, 231);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(41, 13);
            this.label19.TabIndex = 33;
            this.label19.Text = "ID Don";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(22, 200);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(137, 16);
            this.label17.TabIndex = 32;
            this.label17.Text = "Information du Don";
            // 
            // txtTelDonneur
            // 
            this.txtTelDonneur.Location = new System.Drawing.Point(86, 161);
            this.txtTelDonneur.Name = "txtTelDonneur";
            this.txtTelDonneur.Size = new System.Drawing.Size(134, 20);
            this.txtTelDonneur.TabIndex = 31;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(22, 164);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(58, 13);
            this.label16.TabIndex = 30;
            this.label16.Text = "Téléphone";
            // 
            // txtAdresseDonneur
            // 
            this.txtAdresseDonneur.Location = new System.Drawing.Point(86, 135);
            this.txtAdresseDonneur.Name = "txtAdresseDonneur";
            this.txtAdresseDonneur.Size = new System.Drawing.Size(134, 20);
            this.txtAdresseDonneur.TabIndex = 29;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(22, 138);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(45, 13);
            this.label15.TabIndex = 28;
            this.label15.Text = "Adresse";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(22, 26);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(154, 16);
            this.label11.TabIndex = 27;
            this.label11.Text = "Information Donneurs";
            // 
            // txtNomDonneur
            // 
            this.txtNomDonneur.Location = new System.Drawing.Point(86, 109);
            this.txtNomDonneur.Name = "txtNomDonneur";
            this.txtNomDonneur.Size = new System.Drawing.Size(134, 20);
            this.txtNomDonneur.TabIndex = 26;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(22, 112);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 13);
            this.label12.TabIndex = 25;
            this.label12.Text = "Nom";
            // 
            // txtPrenomDonneur
            // 
            this.txtPrenomDonneur.Location = new System.Drawing.Point(86, 83);
            this.txtPrenomDonneur.Name = "txtPrenomDonneur";
            this.txtPrenomDonneur.Size = new System.Drawing.Size(134, 20);
            this.txtPrenomDonneur.TabIndex = 24;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(22, 86);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(43, 13);
            this.label13.TabIndex = 23;
            this.label13.Text = "Prénom";
            // 
            // txtIDDonneur
            // 
            this.txtIDDonneur.Location = new System.Drawing.Point(86, 57);
            this.txtIDDonneur.Name = "txtIDDonneur";
            this.txtIDDonneur.Size = new System.Drawing.Size(134, 20);
            this.txtIDDonneur.TabIndex = 22;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(22, 60);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(18, 13);
            this.label14.TabIndex = 21;
            this.label14.Text = "ID";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.btnAfficherPrix);
            this.tabPage2.Controls.Add(this.btnAjouterPrix);
            this.tabPage2.Controls.Add(this.btnAfficherCommanditaire);
            this.tabPage2.Controls.Add(this.btnAjouterCommanditaire);
            this.tabPage2.Controls.Add(this.txtDonMinimumPrix);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.txtQuantitePrix);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.txtValeurPrix);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.txtDescriptionPrix);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.txtIDPrixCommanditaire);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.txtIDCommanditaire);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.txtNomCommanditaire);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.txtPrenomCommanditaire);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(492, 337);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Commanditaires";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(226, 35);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(114, 16);
            this.label10.TabIndex = 21;
            this.label10.Text = "Information Prix";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(28, 35);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(192, 16);
            this.label9.TabIndex = 20;
            this.label9.Text = "Information Commanditaire";
            // 
            // btnAfficherPrix
            // 
            this.btnAfficherPrix.Location = new System.Drawing.Point(313, 228);
            this.btnAfficherPrix.Name = "btnAfficherPrix";
            this.btnAfficherPrix.Size = new System.Drawing.Size(88, 34);
            this.btnAfficherPrix.TabIndex = 19;
            this.btnAfficherPrix.Text = "Afficher Prix";
            this.btnAfficherPrix.UseVisualStyleBackColor = true;
            this.btnAfficherPrix.Click += new System.EventHandler(this.btnAfficherPrix_Click);
            // 
            // btnAjouterPrix
            // 
            this.btnAjouterPrix.Location = new System.Drawing.Point(219, 228);
            this.btnAjouterPrix.Name = "btnAjouterPrix";
            this.btnAjouterPrix.Size = new System.Drawing.Size(88, 34);
            this.btnAjouterPrix.TabIndex = 18;
            this.btnAjouterPrix.Text = "Ajouter Prix";
            this.btnAjouterPrix.UseVisualStyleBackColor = true;
            this.btnAjouterPrix.Click += new System.EventHandler(this.btnAjouterPrix_Click);
            // 
            // btnAfficherCommanditaire
            // 
            this.btnAfficherCommanditaire.Location = new System.Drawing.Point(125, 228);
            this.btnAfficherCommanditaire.Name = "btnAfficherCommanditaire";
            this.btnAfficherCommanditaire.Size = new System.Drawing.Size(88, 34);
            this.btnAfficherCommanditaire.TabIndex = 17;
            this.btnAfficherCommanditaire.Text = "Afficher Commanditaire";
            this.btnAfficherCommanditaire.UseVisualStyleBackColor = true;
            this.btnAfficherCommanditaire.Click += new System.EventHandler(this.btnAfficherCommanditaire_Click);
            // 
            // btnAjouterCommanditaire
            // 
            this.btnAjouterCommanditaire.Location = new System.Drawing.Point(31, 228);
            this.btnAjouterCommanditaire.Name = "btnAjouterCommanditaire";
            this.btnAjouterCommanditaire.Size = new System.Drawing.Size(88, 34);
            this.btnAjouterCommanditaire.TabIndex = 16;
            this.btnAjouterCommanditaire.Text = "Ajouter Commanditaire";
            this.btnAjouterCommanditaire.UseVisualStyleBackColor = true;
            this.btnAjouterCommanditaire.Click += new System.EventHandler(this.btnAjouterCommanditaire_Click);
            // 
            // txtDonMinimumPrix
            // 
            this.txtDonMinimumPrix.Location = new System.Drawing.Point(313, 170);
            this.txtDonMinimumPrix.Name = "txtDonMinimumPrix";
            this.txtDonMinimumPrix.Size = new System.Drawing.Size(100, 20);
            this.txtDonMinimumPrix.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(224, 173);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(70, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Don minimum";
            // 
            // txtQuantitePrix
            // 
            this.txtQuantitePrix.Location = new System.Drawing.Point(313, 144);
            this.txtQuantitePrix.Name = "txtQuantitePrix";
            this.txtQuantitePrix.Size = new System.Drawing.Size(100, 20);
            this.txtQuantitePrix.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(224, 147);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Quantité";
            // 
            // txtValeurPrix
            // 
            this.txtValeurPrix.Location = new System.Drawing.Point(313, 118);
            this.txtValeurPrix.Name = "txtValeurPrix";
            this.txtValeurPrix.Size = new System.Drawing.Size(100, 20);
            this.txtValeurPrix.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(224, 121);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Valeur / Prix";
            // 
            // txtDescriptionPrix
            // 
            this.txtDescriptionPrix.Location = new System.Drawing.Point(313, 92);
            this.txtDescriptionPrix.Name = "txtDescriptionPrix";
            this.txtDescriptionPrix.Size = new System.Drawing.Size(100, 20);
            this.txtDescriptionPrix.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(224, 95);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Description";
            // 
            // txtIDPrixCommanditaire
            // 
            this.txtIDPrixCommanditaire.Location = new System.Drawing.Point(313, 66);
            this.txtIDPrixCommanditaire.Name = "txtIDPrixCommanditaire";
            this.txtIDPrixCommanditaire.Size = new System.Drawing.Size(100, 20);
            this.txtIDPrixCommanditaire.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(224, 69);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(18, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "ID";
            // 
            // txtIDCommanditaire
            // 
            this.txtIDCommanditaire.Location = new System.Drawing.Point(79, 118);
            this.txtIDCommanditaire.Name = "txtIDCommanditaire";
            this.txtIDCommanditaire.Size = new System.Drawing.Size(134, 20);
            this.txtIDCommanditaire.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(28, 121);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(18, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "ID";
            // 
            // txtNomCommanditaire
            // 
            this.txtNomCommanditaire.Location = new System.Drawing.Point(79, 92);
            this.txtNomCommanditaire.Name = "txtNomCommanditaire";
            this.txtNomCommanditaire.Size = new System.Drawing.Size(134, 20);
            this.txtNomCommanditaire.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(28, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Nom";
            // 
            // txtPrenomCommanditaire
            // 
            this.txtPrenomCommanditaire.Location = new System.Drawing.Point(79, 66);
            this.txtPrenomCommanditaire.Name = "txtPrenomCommanditaire";
            this.txtPrenomCommanditaire.Size = new System.Drawing.Size(134, 20);
            this.txtPrenomCommanditaire.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Prénom";
            // 
            // btnFermer
            // 
            this.btnFermer.Location = new System.Drawing.Point(536, 356);
            this.btnFermer.Name = "btnFermer";
            this.btnFermer.Size = new System.Drawing.Size(75, 23);
            this.btnFermer.TabIndex = 1;
            this.btnFermer.Text = "Fermer";
            this.btnFermer.UseVisualStyleBackColor = true;
            this.btnFermer.Click += new System.EventHandler(this.btnFermer_Click);
            // 
            // rtbArea
            // 
            this.rtbArea.Location = new System.Drawing.Point(12, 422);
            this.rtbArea.Name = "rtbArea";
            this.rtbArea.Size = new System.Drawing.Size(599, 105);
            this.rtbArea.TabIndex = 2;
            this.rtbArea.Text = "";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fichierToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(626, 24);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fichierToolStripMenuItem
            // 
            this.fichierToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.importerToolStripMenuItem,
            this.exporterToolStripMenuItem});
            this.fichierToolStripMenuItem.Name = "fichierToolStripMenuItem";
            this.fichierToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.fichierToolStripMenuItem.Text = "Fichier";
            // 
            // importerToolStripMenuItem
            // 
            this.importerToolStripMenuItem.Name = "importerToolStripMenuItem";
            this.importerToolStripMenuItem.Size = new System.Drawing.Size(120, 22);
            this.importerToolStripMenuItem.Text = "Importer";
            this.importerToolStripMenuItem.Click += new System.EventHandler(this.importerToolStripMenuItem_Click);
            // 
            // exporterToolStripMenuItem
            // 
            this.exporterToolStripMenuItem.Name = "exporterToolStripMenuItem";
            this.exporterToolStripMenuItem.Size = new System.Drawing.Size(120, 22);
            this.exporterToolStripMenuItem.Text = "Exporter";
            this.exporterToolStripMenuItem.Click += new System.EventHandler(this.exporterToolStripMenuItem_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(626, 531);
            this.Controls.Add(this.rtbArea);
            this.Controls.Add(this.btnFermer);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Système Téléton STE";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form2_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form2_FormClosed);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.grBoxTypeCarte.ResumeLayout(false);
            this.grBoxTypeCarte.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnAfficherPrix;
        private System.Windows.Forms.Button btnAjouterPrix;
        private System.Windows.Forms.Button btnAfficherCommanditaire;
        private System.Windows.Forms.Button btnAjouterCommanditaire;
        private System.Windows.Forms.TextBox txtDonMinimumPrix;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtQuantitePrix;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtValeurPrix;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtDescriptionPrix;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtIDPrixCommanditaire;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtIDCommanditaire;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNomCommanditaire;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtPrenomCommanditaire;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnFermer;
        private System.Windows.Forms.RichTextBox rtbArea;
        private System.Windows.Forms.TextBox txtTelDonneur;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtAdresseDonneur;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtNomDonneur;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtPrenomDonneur;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtIDDonneur;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtDateExpirationCarte;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtNumeroCarte;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.GroupBox grBoxTypeCarte;
        private System.Windows.Forms.RadioButton rbAmex;
        private System.Windows.Forms.RadioButton rbMasterCard;
        private System.Windows.Forms.RadioButton rbVisa;
        private System.Windows.Forms.TextBox txtMontantDon;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtIDDon;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button btnAfficherDonneur;
        private System.Windows.Forms.Button btnAjouterDonneur;
        private System.Windows.Forms.Button btnAfficherDon;
        private System.Windows.Forms.Button btnAjouterDon;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtNombreDePrix;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtIDPrixDonneurs;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fichierToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem importerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exporterToolStripMenuItem;
    }
}